using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Launcher.Modules.Models;

public class WildcardFile
{
    /// <summary>Nombre como se usa en el prompt (__nombre__): ruta relativa sin .txt, con "/".</summary>
    public string Name { get; set; } = "";
    public string FullPath { get; set; } = "";
    public string Root { get; set; } = "";

    /// <summary>Entradas reales: sin contar lineas en blanco ni comentarios (#).</summary>
    public int LineCount { get; set; }

    /// <summary>Etiquetas &lt;lora:...&gt; / &lt;lyco:...&gt; que contiene.</summary>
    public int ModelRefCount { get; set; }

    public DateTime Modified { get; set; }
}

public class WildcardReference
{
    public string Kind { get; set; } = "lora";
    public string ModelName { get; set; } = "";
    public string? Weight { get; set; }
    public int LineNumber { get; set; }
    public string Line { get; set; } = "";
}

/// <summary>
/// Lectura de wildcards de Dynamic Prompts. SOLO LECTURA por ahora: no hay ningun metodo que escriba.
/// La edicion (linea a linea, con copia de seguridad y confirmacion) llega en el paso 3.
/// </summary>
public sealed class WildcardService
{
    public static WildcardService Instance { get; } = new();

    private static readonly Regex ModelTag = new(
        @"<(?<kind>lora|lyco):(?<name>[^:>]+)(?::(?<weight>[^>]*))?>",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private WildcardService() { }

    public Task<List<WildcardFile>> ListFilesAsync() => Task.Run(ListFiles);

    private static List<WildcardFile> ListFiles()
    {
        var result = new List<WildcardFile>();
        var options = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true };

        foreach (var rawRoot in ModelsSettings.Instance.WildcardFoldersEffective().Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!Directory.Exists(rawRoot)) continue;

            foreach (var path in Directory.EnumerateFiles(rawRoot, "*.txt", options))
            {
                try
                {
                    var lines = ReadLines(path);
                    var entries = lines.Where(IsEntry).ToList();

                    result.Add(new WildcardFile
                    {
                        Name = Path.GetRelativePath(rawRoot, path)
                            .Replace('\\', '/')[..^4], // quita ".txt"
                        FullPath = path,
                        Root = rawRoot,
                        LineCount = entries.Count,
                        ModelRefCount = entries.Sum(l => ModelTag.Matches(l).Count),
                        Modified = File.GetLastWriteTime(path)
                    });
                }
                catch
                {
                    // Un archivo ilegible no debe tumbar el listado de los demas.
                }
            }
        }

        return result.OrderBy(w => w.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private static bool IsEntry(string line) =>
        !string.IsNullOrWhiteSpace(line) && !line.TrimStart().StartsWith('#');

    /// <summary>Lee un archivo tal cual esta, sin bloquearlo (A1111 puede tenerlo abierto).</summary>
    public static string[] ReadLines(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);
        var lines = new List<string>();
        while (reader.ReadLine() is { } line) lines.Add(line);
        return lines.ToArray();
    }

    /// <summary>Etiquetas de modelo de un archivo, con su numero de linea (1-based).</summary>
    public static List<WildcardReference> ExtractReferences(IReadOnlyList<string> lines)
    {
        var refs = new List<WildcardReference>();

        for (var i = 0; i < lines.Count; i++)
        {
            if (!IsEntry(lines[i])) continue;

            foreach (Match match in ModelTag.Matches(lines[i]))
            {
                refs.Add(new WildcardReference
                {
                    Kind = match.Groups["kind"].Value.ToLowerInvariant(),
                    ModelName = match.Groups["name"].Value.Trim(),
                    Weight = match.Groups["weight"].Success ? match.Groups["weight"].Value.Trim() : null,
                    LineNumber = i + 1,
                    Line = lines[i]
                });
            }
        }

        return refs;
    }
}
